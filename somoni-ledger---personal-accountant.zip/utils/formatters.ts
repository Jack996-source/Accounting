
import { CURRENCY_SYMBOL } from '../constants';

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('tg-TJ', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount) + ' ' + CURRENCY_SYMBOL;
};

export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};
