
import { GoogleGenAI } from "@google/genai";
import { Transaction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getFinancialAdvice = async (transactions: Transaction[]): Promise<string> => {
  if (transactions.length === 0) return "Add some transactions to get personalized financial advice!";

  const summary = transactions.map(t => `${t.date}: ${t.name} (${t.type}) - ${t.amount} смн`).join('\n');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are an expert personal accountant in Tajikistan. Analyze the following transaction history and provide a concise, encouraging summary in 3-4 bullet points. Mention spending patterns and suggestions for saving in Somoni (TJS).
      
      Transactions:
      ${summary}`,
      config: {
        systemInstruction: "You are a professional financial advisor named Somoni Assistant. You are friendly and speak in a modern professional tone.",
        temperature: 0.7,
      },
    });

    return response.text || "I couldn't analyze the data at this moment.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The AI assistant is currently unavailable (check your connection or API key).";
  }
};
