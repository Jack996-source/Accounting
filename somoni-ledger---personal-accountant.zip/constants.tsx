
export const CATEGORIES = [
  'Salary',
  'Business',
  'Gift',
  'Investment',
  'Food',
  'Transport',
  'Shopping',
  'Rent',
  'Utilities',
  'Health',
  'Other'
];

export const CURRENCY_SYMBOL = 'смн';
export const CURRENCY_CODE = 'TJS';
