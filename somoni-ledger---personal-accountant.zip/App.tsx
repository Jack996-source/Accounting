
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Transaction, TransactionType, TimePeriod } from './types';
import { getTransactions, saveTransactions } from './services/storageService';
import { getFinancialAdvice } from './services/geminiService';
import SummaryCard from './components/SummaryCard';
import TransactionForm from './components/TransactionForm';
import Charts from './components/Charts';
import { formatCurrency, formatDate } from './utils/formatters';

const App: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [timeFilter, setTimeFilter] = useState<TimePeriod>('month');
  const [aiAdvice, setAiAdvice] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = getTransactions();
    setTransactions(saved);
  }, []);

  const handleAddTransaction = (newT: Omit<Transaction, 'id'>) => {
    const fullT: Transaction = {
      ...newT,
      id: Math.random().toString(36).substr(2, 9),
    };
    const updated = [fullT, ...transactions];
    setTransactions(updated);
    saveTransactions(updated);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this transaction?')) {
      const updated = transactions.filter(t => t.id !== id);
      setTransactions(updated);
      saveTransactions(updated);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Somoni Ledger',
          text: 'Check out my finances in Somoni Ledger!',
          url: window.location.href,
        });
      } catch (err) {
        console.log('Error sharing', err);
      }
    } else {
      alert('Sharing is not supported on this browser.');
    }
  };

  const exportData = () => {
    const dataStr = JSON.stringify(transactions, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `somoni_ledger_backup_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        if (Array.isArray(json)) {
          if (window.confirm('This will replace your current data. Continue?')) {
            setTransactions(json);
            saveTransactions(json);
          }
        }
      } catch (err) {
        alert('Invalid backup file.');
      }
    };
    reader.readAsText(file);
  };

  const filteredTransactions = useMemo(() => {
    const now = new Date();
    return transactions.filter(t => {
      const tDate = new Date(t.date);
      if (timeFilter === 'day') return tDate.toDateString() === now.toDateString();
      if (timeFilter === 'week') {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return tDate >= weekAgo;
      }
      if (timeFilter === 'month') return tDate.getMonth() === now.getMonth() && tDate.getFullYear() === now.getFullYear();
      if (timeFilter === 'year') return tDate.getFullYear() === now.getFullYear();
      return true;
    });
  }, [transactions, timeFilter]);

  const totals = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => {
      if (t.type === TransactionType.INCOME) acc.income += t.amount;
      else acc.expense += t.amount;
      return acc;
    }, { income: 0, expense: 0 });
  }, [filteredTransactions]);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    const advice = await getFinancialAdvice(filteredTransactions);
    setAiAdvice(advice);
    setIsAnalyzing(false);
  };

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-30 px-4 py-4 md:px-8">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 leading-tight">Somoni Ledger</h1>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Accountant</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-1">
             <button 
                onClick={handleShare}
                className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-xl transition-all active:scale-90"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"></path></svg>
              </button>
              <button 
                onClick={exportData}
                className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-xl transition-all"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
              </button>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-xl transition-all"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
              </button>
              <input type="file" ref={fileInputRef} onChange={importData} className="hidden" accept=".json" />
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 space-y-8">
        {/* Date Filters */}
        <div className="flex overflow-x-auto pb-2 space-x-2 no-scrollbar">
          {(['day', 'week', 'month', 'year'] as TimePeriod[]).map(p => (
            <button
              key={p}
              onClick={() => setTimeFilter(p)}
              className={`flex-shrink-0 px-6 py-2.5 text-sm font-bold rounded-2xl transition-all ${timeFilter === p ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'}`}
            >
              {p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <SummaryCard title="Earnings" amount={totals.income} type="income" icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>} />
          <SummaryCard title="Expenses" amount={totals.expense} type="expense" icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"></path></svg>} />
          <SummaryCard title="Savings" amount={totals.income - totals.expense} type="neutral" icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>} />
        </div>

        {/* AI Insight */}
        <div className="bg-slate-900 rounded-[2rem] p-8 text-white shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-20 rotate-12">
            <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path></svg>
          </div>
          <div className="relative z-10 space-y-4">
            <div className="flex items-center space-x-2">
              <span className="bg-indigo-500 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter">AI Insight</span>
              <h3 className="text-xl font-bold">Financial Advice</h3>
            </div>
            <div className="min-h-[60px]">
              {aiAdvice ? (
                <p className="text-slate-300 leading-relaxed text-sm whitespace-pre-line font-medium">{aiAdvice}</p>
              ) : (
                <p className="text-slate-400 italic text-sm">Tap analyze to get personalized insights on your spending.</p>
              )}
            </div>
            <button 
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className="w-full md:w-auto bg-indigo-600 text-white px-8 py-3.5 rounded-2xl font-bold text-sm hover:bg-indigo-500 transition-all disabled:opacity-50 active:scale-95 shadow-lg shadow-indigo-900/40"
            >
              {isAnalyzing ? 'Thinking...' : 'Analyze Now'}
            </button>
          </div>
        </div>

        <Charts transactions={transactions} />

        {/* History */}
        <div className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden">
          <div className="px-6 py-6 border-b border-slate-100 flex justify-between items-center">
            <h3 className="text-lg font-bold text-slate-800">Recent Activity</h3>
            <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full uppercase">{filteredTransactions.length} items</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[600px]">
              <thead className="bg-slate-50/50">
                <tr>
                  <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest">Description</th>
                  <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest">Category</th>
                  <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest">Date</th>
                  <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Amount</th>
                  <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTransactions.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-5">
                      <div className="flex items-center">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center mr-3 text-sm font-bold ${t.type === TransactionType.INCOME ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                          {t.type === TransactionType.INCOME ? '↙' : '↗'}
                        </div>
                        <span className="font-semibold text-slate-800">{t.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-5">
                      <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-lg">
                        {t.category}
                      </span>
                    </td>
                    <td className="px-6 py-5 text-slate-400 text-sm font-medium">
                      {formatDate(t.date)}
                    </td>
                    <td className={`px-6 py-5 text-right font-bold text-base ${t.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-slate-900'}`}>
                      {t.type === TransactionType.INCOME ? '+' : '-'}{formatCurrency(t.amount)}
                    </td>
                    <td className="px-6 py-5 text-center">
                      <button 
                        onClick={() => handleDelete(t.id)}
                        className="p-2 text-slate-300 hover:text-rose-500 transition-colors"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* FAB */}
      <button 
        onClick={() => setShowForm(true)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-indigo-600 text-white rounded-2xl shadow-2xl shadow-indigo-300 flex items-center justify-center hover:scale-110 active:scale-95 transition-all z-40"
      >
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
      </button>

      {showForm && (
        <TransactionForm onAdd={handleAddTransaction} onClose={() => setShowForm(false)} />
      )}
    </div>
  );
};

export default App;
