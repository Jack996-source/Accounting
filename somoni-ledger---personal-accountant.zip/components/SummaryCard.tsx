
import React from 'react';
import { formatCurrency } from '../utils/formatters';

interface SummaryCardProps {
  title: string;
  amount: number;
  type: 'income' | 'expense' | 'neutral';
  icon: React.ReactNode;
}

const SummaryCard: React.FC<SummaryCardProps> = ({ title, amount, type, icon }) => {
  const getColors = () => {
    switch (type) {
      case 'income': return 'text-emerald-600 bg-emerald-50';
      case 'expense': return 'text-rose-600 bg-rose-50';
      default: return 'text-indigo-600 bg-indigo-50';
    }
  };

  return (
    <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4">
      <div className={`p-3 rounded-xl ${getColors()}`}>
        {icon}
      </div>
      <div>
        <p className="text-slate-500 text-sm font-medium">{title}</p>
        <p className={`text-xl font-bold ${type === 'expense' ? 'text-slate-800' : 'text-slate-900'}`}>
          {formatCurrency(amount)}
        </p>
      </div>
    </div>
  );
};

export default SummaryCard;
